﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*定义委托*/
namespace 例4._6
{
    delegate int Max(int first, int second);
}
